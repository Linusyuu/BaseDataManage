﻿namespace com.zstu.BaseForm
{
    partial class FBaseDataManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LbComboDetail = new System.Windows.Forms.ListBox();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnDel = new System.Windows.Forms.Button();
            this.TbComboValue = new System.Windows.Forms.TextBox();
            this.BtnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tvComboName = new System.Windows.Forms.TreeView();
            this.cmsComboName = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmDorefresh = new System.Windows.Forms.ToolStripMenuItem();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_down = new System.Windows.Forms.Button();
            this.bt_up = new System.Windows.Forms.Button();
            this.tvComboDetail = new System.Windows.Forms.TreeView();
            this.cmsComboDetail = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.DeleteTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.UpTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.DownTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.RefreshTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.rbSing = new System.Windows.Forms.RadioButton();
            this.rbMult = new System.Windows.Forms.RadioButton();
            this.lbComboName = new System.Windows.Forms.Label();
            this.lbParentName = new System.Windows.Forms.Label();
            this.tbParent = new System.Windows.Forms.TextBox();
            this.cmsComboName.SuspendLayout();
            this.cmsComboDetail.SuspendLayout();
            this.SuspendLayout();
            // 
            // LbComboDetail
            // 
            this.LbComboDetail.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LbComboDetail.FormattingEnabled = true;
            this.LbComboDetail.ItemHeight = 19;
            this.LbComboDetail.Location = new System.Drawing.Point(856, 26);
            this.LbComboDetail.Name = "LbComboDetail";
            this.LbComboDetail.Size = new System.Drawing.Size(235, 232);
            this.LbComboDetail.TabIndex = 1;
            this.LbComboDetail.Visible = false;
            // 
            // BtnAdd
            // 
            this.BtnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnAdd.Location = new System.Drawing.Point(413, 612);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(75, 23);
            this.BtnAdd.TabIndex = 2;
            this.BtnAdd.Text = "添加";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnDel
            // 
            this.BtnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnDel.Location = new System.Drawing.Point(545, 612);
            this.BtnDel.Name = "BtnDel";
            this.BtnDel.Size = new System.Drawing.Size(75, 23);
            this.BtnDel.TabIndex = 3;
            this.BtnDel.Text = "删除";
            this.BtnDel.UseVisualStyleBackColor = true;
            this.BtnDel.Click += new System.EventHandler(this.BtnDel_Click);
            // 
            // TbComboValue
            // 
            this.TbComboValue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TbComboValue.Location = new System.Drawing.Point(477, 584);
            this.TbComboValue.Name = "TbComboValue";
            this.TbComboValue.Size = new System.Drawing.Size(224, 21);
            this.TbComboValue.TabIndex = 4;
            // 
            // BtnClose
            // 
            this.BtnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnClose.Location = new System.Drawing.Point(675, 612);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(75, 23);
            this.BtnClose.TabIndex = 5;
            this.BtnClose.Text = "关闭";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(442, 587);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "内容";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "下拉框列表";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(393, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "下拉框内容";
            // 
            // tvComboName
            // 
            this.tvComboName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tvComboName.ContextMenuStrip = this.cmsComboName;
            this.tvComboName.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tvComboName.Location = new System.Drawing.Point(12, 35);
            this.tvComboName.Name = "tvComboName";
            this.tvComboName.Size = new System.Drawing.Size(358, 605);
            this.tvComboName.TabIndex = 9;
            this.tvComboName.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.tvComboName_AfterLabelEdit);
            this.tvComboName.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvComboName_AfterSelect);
            // 
            // cmsComboName
            // 
            this.cmsComboName.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmsComboName.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmDorefresh});
            this.cmsComboName.Name = "contextMenuStrip1";
            this.cmsComboName.Size = new System.Drawing.Size(101, 26);
            // 
            // tsmDorefresh
            // 
            this.tsmDorefresh.Name = "tsmDorefresh";
            this.tsmDorefresh.Size = new System.Drawing.Size(100, 22);
            this.tsmDorefresh.Text = "刷新";
            this.tsmDorefresh.Click += new System.EventHandler(this.tsmDorefresh_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(139, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "下拉框类型";
            // 
            // btn_down
            // 
            this.btn_down.Location = new System.Drawing.Point(1097, 234);
            this.btn_down.Name = "btn_down";
            this.btn_down.Size = new System.Drawing.Size(55, 31);
            this.btn_down.TabIndex = 12;
            this.btn_down.Text = "向下";
            this.btn_down.UseVisualStyleBackColor = true;
            this.btn_down.Visible = false;
            this.btn_down.Click += new System.EventHandler(this.bt_down_Click);
            // 
            // bt_up
            // 
            this.bt_up.Location = new System.Drawing.Point(1097, 197);
            this.bt_up.Name = "bt_up";
            this.bt_up.Size = new System.Drawing.Size(55, 31);
            this.bt_up.TabIndex = 13;
            this.bt_up.Text = "向上";
            this.bt_up.UseVisualStyleBackColor = true;
            this.bt_up.Visible = false;
            this.bt_up.Click += new System.EventHandler(this.bt_up_Click);
            // 
            // tvComboDetail
            // 
            this.tvComboDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tvComboDetail.ContextMenuStrip = this.cmsComboDetail;
            this.tvComboDetail.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tvComboDetail.Location = new System.Drawing.Point(395, 65);
            this.tvComboDetail.Name = "tvComboDetail";
            this.tvComboDetail.Size = new System.Drawing.Size(378, 456);
            this.tvComboDetail.TabIndex = 14;
            this.tvComboDetail.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.tvComboDetail_AfterLabelEdit);
            this.tvComboDetail.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvComboDetail_AfterSelect);
            // 
            // cmsComboDetail
            // 
            this.cmsComboDetail.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddTSMI,
            this.DeleteTSMI,
            this.UpTSMI,
            this.DownTSMI,
            this.RefreshTSMI});
            this.cmsComboDetail.Name = "cmsComboDetail";
            this.cmsComboDetail.Size = new System.Drawing.Size(101, 114);
            // 
            // AddTSMI
            // 
            this.AddTSMI.Name = "AddTSMI";
            this.AddTSMI.Size = new System.Drawing.Size(100, 22);
            this.AddTSMI.Text = "添加";
            this.AddTSMI.Click += new System.EventHandler(this.AddTSMI_Click);
            // 
            // DeleteTSMI
            // 
            this.DeleteTSMI.Name = "DeleteTSMI";
            this.DeleteTSMI.Size = new System.Drawing.Size(100, 22);
            this.DeleteTSMI.Text = "删除";
            this.DeleteTSMI.Click += new System.EventHandler(this.DeleteTSMI_Click);
            // 
            // UpTSMI
            // 
            this.UpTSMI.Name = "UpTSMI";
            this.UpTSMI.Size = new System.Drawing.Size(100, 22);
            this.UpTSMI.Text = "向上";
            this.UpTSMI.Click += new System.EventHandler(this.UpTSMI_Click);
            // 
            // DownTSMI
            // 
            this.DownTSMI.Name = "DownTSMI";
            this.DownTSMI.Size = new System.Drawing.Size(100, 22);
            this.DownTSMI.Text = "向下";
            this.DownTSMI.Click += new System.EventHandler(this.DownTSMI_Click);
            // 
            // RefreshTSMI
            // 
            this.RefreshTSMI.Name = "RefreshTSMI";
            this.RefreshTSMI.Size = new System.Drawing.Size(100, 22);
            this.RefreshTSMI.Text = "刷新";
            this.RefreshTSMI.Click += new System.EventHandler(this.RefreshTSMI_Click);
            // 
            // rbSing
            // 
            this.rbSing.AutoSize = true;
            this.rbSing.Location = new System.Drawing.Point(225, 10);
            this.rbSing.Name = "rbSing";
            this.rbSing.Size = new System.Drawing.Size(47, 16);
            this.rbSing.TabIndex = 15;
            this.rbSing.TabStop = true;
            this.rbSing.Text = "单选";
            this.rbSing.UseVisualStyleBackColor = true;
            this.rbSing.CheckedChanged += new System.EventHandler(this.rbSing_CheckedChanged);
            // 
            // rbMult
            // 
            this.rbMult.AutoSize = true;
            this.rbMult.Location = new System.Drawing.Point(288, 10);
            this.rbMult.Name = "rbMult";
            this.rbMult.Size = new System.Drawing.Size(47, 16);
            this.rbMult.TabIndex = 16;
            this.rbMult.TabStop = true;
            this.rbMult.Text = "多选";
            this.rbMult.UseVisualStyleBackColor = true;
            this.rbMult.CheckedChanged += new System.EventHandler(this.rbMult_CheckedChanged);
            // 
            // lbComboName
            // 
            this.lbComboName.AutoSize = true;
            this.lbComboName.Location = new System.Drawing.Point(453, 12);
            this.lbComboName.Name = "lbComboName";
            this.lbComboName.Size = new System.Drawing.Size(125, 12);
            this.lbComboName.TabIndex = 17;
            this.lbComboName.Text = "当前选择的下拉框是：";
            // 
            // lbParentName
            // 
            this.lbParentName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lbParentName.AutoSize = true;
            this.lbParentName.Location = new System.Drawing.Point(430, 553);
            this.lbParentName.Name = "lbParentName";
            this.lbParentName.Size = new System.Drawing.Size(41, 12);
            this.lbParentName.TabIndex = 18;
            this.lbParentName.Text = "父节点";
            // 
            // tbParent
            // 
            this.tbParent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tbParent.Location = new System.Drawing.Point(477, 550);
            this.tbParent.Name = "tbParent";
            this.tbParent.ReadOnly = true;
            this.tbParent.Size = new System.Drawing.Size(224, 21);
            this.tbParent.TabIndex = 19;
            // 
            // FBaseDataManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 656);
            this.Controls.Add(this.tbParent);
            this.Controls.Add(this.lbParentName);
            this.Controls.Add(this.lbComboName);
            this.Controls.Add(this.rbMult);
            this.Controls.Add(this.rbSing);
            this.Controls.Add(this.tvComboDetail);
            this.Controls.Add(this.bt_up);
            this.Controls.Add(this.btn_down);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tvComboName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.TbComboValue);
            this.Controls.Add(this.BtnDel);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.LbComboDetail);
            this.KeyPreview = true;
            this.Name = "FBaseDataManage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "下拉框维护";
            this.Load += new System.EventHandler(this.FBaseDataManage_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FBaseDataManage_KeyDown);
            this.cmsComboName.ResumeLayout(false);
            this.cmsComboDetail.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox LbComboDetail;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnDel;
        private System.Windows.Forms.TextBox TbComboValue;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TreeView tvComboName;
        private System.Windows.Forms.ContextMenuStrip cmsComboName;
        private System.Windows.Forms.ToolStripMenuItem tsmDorefresh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_down;
        private System.Windows.Forms.Button bt_up;
        private System.Windows.Forms.TreeView tvComboDetail;
        private System.Windows.Forms.RadioButton rbSing;
        private System.Windows.Forms.RadioButton rbMult;
        private System.Windows.Forms.Label lbComboName;
        private System.Windows.Forms.ContextMenuStrip cmsComboDetail;
        private System.Windows.Forms.ToolStripMenuItem AddTSMI;
        private System.Windows.Forms.ToolStripMenuItem DeleteTSMI;
        private System.Windows.Forms.ToolStripMenuItem UpTSMI;
        private System.Windows.Forms.ToolStripMenuItem DownTSMI;
        private System.Windows.Forms.ToolStripMenuItem RefreshTSMI;
        private System.Windows.Forms.Label lbParentName;
        private System.Windows.Forms.TextBox tbParent;
    }
}